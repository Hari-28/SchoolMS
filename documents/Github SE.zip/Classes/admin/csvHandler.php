<?php
//include './classes/admin/validateCsv.php';
class csvUpload extends Database{
	
		function csvUploader()
			{
				$this->fileUp();
					if(isset($_POST['add_user']))
					{
							
							$file = fopen("temp","r");
							print_r(fgetcsv($file));
							fclose($file);
					}
					if(isset($_POST['add_student']))
					{
							//validateStudent
							$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->uploadStudentList($values);
							}
							fclose($file);
					}
					if(isset($_POST['add_courses']))
					{
						//validateStudent
							$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->uploadCourseList($values);
							}
							fclose($file);
					}
					if(isset($_POST['add_faculty']))
					{
							$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->uploadFacultyList($values);
							}
							fclose($file);
					}
					if(isset($_POST['add_departments']))
					{
					
					}
					if(isset($_POST['add_programme']))
					{
					
					}
					if(isset($_POST['add_grade']))
					{
						$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->uploadGradeList($values);
							}
							fclose($file);
				
					}
					if(isset($_POST['set_reg']))
					{
							$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->acad_aprove($values);
							}
							fclose($file);
							
						
					}
					if(isset($_POST['set_reg']))
					{
						
					}
			}
		
		function StuRegDetails()
			{
					
			}
		
		function acad_aprove($values)
			{
					//echo "sasasassjdsafdjsjdgjasgd";
				
					$conn= $this->Connection();
					$sql =  "call set_registration_applicability( ? , ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('si',$values[0],$values[1]);
					$stmnt->execute();
					$conn->close();
			
			
			}
		
		function fileUp()
			{
			if(isset($_FILES['datafile']))
				{
				move_uploaded_file($_FILES["datafile"]["tmp_name"], "temp");
			//	header("Location: ./l.php");				

				}
   
			}
		
		function uploadStudentList($values)
		{
			$name=$values[0];
			$roll=$values[1];
			$dept=$values[2];
			$programme=$values[3];
			$username=$values[4];
			$password=$values[5];
			$email=$values[6];
			$start_date=$values[7];
			$end_date=$values[8];


			/*

			//email

			if(filter_var($email, FILTER_VALIDATE_EMAIL))
				echo "true";
			else
				echo "false";

			//date

			$format = 'Y-m-d';
			$d = DateTime::createFromFormat($format, $start_date);
			if($d && $d->format($format) == $start_date)
				echo true;
			else 
				echo false;


			*/
			
			echo $end_date."</br>";
					$conn= $this->Connection();
					$sql =  "call add_student( ?,?,?,?,?,?,?,?,?)";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('ssiisssss',$name,$roll,$programme,$start_date,$end_date,$email,$dept,$username,$password);
					$stmnt->execute();
					$conn->close();
			
		}
		
		function uploadFacultyList($values)
		{
			//Faculty_name,department_name,username,password,email
			$name=$values[0];
			$dept=$values[1];
			$username=$values[2];
			$email=$values[3];

			echo $name.$dept.$username.$email;
			/*
					$conn= $this->Connection();
					$sql =  "call add_student( ?,?,?,? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('siss',$name,$dept,$username,$email);
					$stmnt->execute();
					$conn->close();
					ldsahh j )(I);
			*/
		}		
	function uploadGradeList($values)
		{
			//Student_roll_number,course_number,year,semester,grade
			$roll=$values[0];
			$course=$values[1];
			$year=$values[2];
			$semester=$values[3];
			$grade=$values[4];

		//	echo $roll.$course.$year.$semester.$grade;
			
					$conn= $this->Connection();
					$sql =  "call add_student_grade( ?,?,?,?,? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('ssiii',$roll,$course ,$year ,$semester,$grade);
					$stmnt->execute();
					$conn->close();
			
		}		

	function uploadCourseList($values)
		{
			//Course_name,course_number,course_description,lecture_credits,tutorial_credits,practical_credits,start_date,end_date
			$name=$values[0];
			$number=$values[1];
			$description=$values[2];
			$lec_credit=$values[3];
			$tut_credit=$values[4];
			$prac_credit=$values[5];
			$start_date=$values[6];
			$end_date=$values[7];
			

				//echo $name.$number.$description.$lec_credit;
			
					$conn= $this->Connection();
					$sql =  "call add_student( ?,?,?,?,?,?,?,? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('sssiiiss',$name,$number,$description,$lec_credit,$tut_credit,$prac_credit,$start_date,$end_date);
					$stmnt->execute();
					$conn->close();
			
		}		
	function uploadCourseCurriculumList($values)
		{
			//Course_name,course_number,course_description,lecture_credits,tutorial_credits,practical_credits,start_date,end_date
			$name=$values[0];
			$number=$values[1];
			$description=$values[2];
			$lec_credit=$values[3];
			$tut_credit=$values[4];
			$prac_credit=$values[5];
			$start_date=$values[6];
			$end_date=$values[7];
			

			echo $name.$number.$description.$lec_credit;
			/*
					$conn= $this->Connection();
					$sql =  "call add_student( ?,?,?,?,?,?,?,? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('siss',$name,$number,$description,$lec_credit,$tut_credit,$prac_credit,start_date,end_date);
					$stmnt->execute();
					$conn->close();
			*/
		}		
}
?>