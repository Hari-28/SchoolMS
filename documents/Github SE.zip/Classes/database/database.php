<?php
class Database 
	{
	
	 function Connection()
		{
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "gb";
			// Create connection
			$conn = new mysqli($servername, $username, $password,$dbname);
			// Check connection
			if ($conn->connect_error) {
				
				die("Databse Connection Failed: " . $conn->connect_error);
				
				return null;
				} 
			
			return $conn;

		}

	}


?>