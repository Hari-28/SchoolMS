<?php
include './classes/database/Database.php';
class Password extends Database{
	
		function resetPassword()
			{
					if(isset($_POST['npass']))
					{
					$conn= $this->Connection();
					$sql =  "call reset_password ( ? , ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('ss',$_POST['roll'],$_POST['npass']);
					$stmnt->execute();
					$stmnt->bind_result($boolean);
					$row = $stmnt->fetch();
			        if($boolean==1)
						echo "Succesfully Reset password";
					else
						echo "No such roll number exists";
			
					}
			}
		
		
		
   }
?>