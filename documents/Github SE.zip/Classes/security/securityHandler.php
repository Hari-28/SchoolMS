<?php
	function accessValidator()
		{
				if(!(isset($_SESSION['role_id'])))
					{
						header("Location: ./login.php");						
					}
			
		}
	function adminValidator()
		{
				if((isset($_SESSION['role_id'])))
					{
						if($_SESSION['role_id']==0)
							header("Location: ./studentmainpage.php");						
						else if($_SESSION['role_id']==1)
							header("Location: ./faculty.php");						
					
					}		
			
		}
	function studentValidator()
		{
				if((isset($_SESSION['role_id'])))
					{
						if($_SESSION['role_id']==2)
							header("Location: ./adminmainpage.php");						
						else if($_SESSION['role_id']==1)
							header("Location: ./faculty.php");						
					}
			
		}
	function facultyValidator()
		{
				if((isset($_SESSION['role_id'])))
					{
					if($_SESSION['role_id']==0)
							header("Location: ./studentmainpage.php");						
						else if($_SESSION['role_id']==2)
							header("Location: ./adminmainpage.php");						
					}
			
		}
?>