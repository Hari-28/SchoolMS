<?php
include './classes/database/Database.php';
class StudentDetails extends Database{
	
		function GetDetails($username)
			{
					$conn= $this->Connection();
					$sql =  "call give_details_student ( ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('s',$username);
					$stmnt->execute();
					$stmnt->bind_result($_SESSION['student_name'],$_SESSION['roll_number'],$_SESSION['programme_name'],$_SESSION['department_name']);
					$row = $stmnt->fetch();
			
			}
		
		function getSemRegStatus()
			{
					$conn= $this->Connection();
					$sql =  "call registration_status_semester( ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('s',$_SESSION['roll_number']);
					$stmnt->execute();
					$stmnt->bind_result($_SESSION['student_registration_status'],$_SESSION['semester']);
					$row = $stmnt->fetch();
					$conn->close();
			
			}
		
   }
?>