<?php
include './classes/database/Database.php';
class CourseDetails extends Database{
	
		function GetDetails()
			{
					$temp=0;
					$conn= $this->Connection();
					$sql =  "call names_of_courses('".$_SESSION['roll_number']."','".$_SESSION['programme_name']."','".$_SESSION['department_name']."')";
					$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							 while($row = $result->fetch_assoc()) 
							 {
						$_SESSION['course_type'][$temp]=$row['course_type_id'];
						$_SESSION['course_number'][$temp]=$row['course_number'];
						$_SESSION['course_name'][$temp]=$row['course_name'];
						$_SESSION['lecture'][$temp]=$row['lecture'];
						$_SESSION['tutorial'][$temp]=$row['tutorial'];
						$_SESSION['practical'][$temp]=$row['practical'];
						$_SESSION['total_credits'][$temp]=$_SESSION['lecture'][$temp]*2+$_SESSION['tutorial'][$temp]*2+$_SESSION['practical'][$temp];
						$_SESSION['backlog_status'][$temp]=$row['backlog'];
						//$_SESSION['course_type_name'][$temp]=$this->convertCourseTypeId($_SESSION['course_type'][$temp]);
						$temp++;
								 
							 }
						}
						
			}
		
		function convertCourseTypeId($course)
			{
				
				switch($course)
				{
				case 1: return 'Core';
				case 2: return 'Elective';
				case 3: return 'Normal Project';
				case 7: return 'Optional Project';					
				default: return 'error';
				}
			}
		
  }
?>