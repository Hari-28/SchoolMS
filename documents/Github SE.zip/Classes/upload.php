<?php
include '/classes/sql.php';
class Uploader extends Database{
		function upload($filename)
		{
			if(isset($_FILES[$filename]))
				{
					echo "lol";
					move_uploaded_file($_FILES[$filename]["tmp_name"], "temp");
					$this->Parser();
				}

		}
		
		
 		function Parser()
		{
			$file=fopen("temp","r");
			if($file)
				{
					while(!feof($file))
						{
							$content=explode(',',fgets($file))
						//print_r($content);
		//		$this->insert($content);
						}
					fclose($file);
					unlink('temp');
				}
		}
		
	

/*
		function insert($content)
			{
			$conn=$this->Connection();
			$sql = "select role_id from users where username='".$user."' and password='".$pass."'";
			$result = $conn->query($sql);
			}
	*/	
?>