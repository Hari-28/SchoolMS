<?php
include './classes/database/Database.php';
class GradeDetails extends Database{
	
		function GetCpiSpi($roll_number)
			{
					$temp=0;
					$conn= $this->Connection();
					$sql =  "call cpi_spi( ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('s',$roll_number);
					$stmnt->execute();
					
					
					while(1)
					{
						$stmnt->bind_result($_SESSION['semester_grade'][$temp],$_SESSION['year'][$temp],$_SESSION['spi'][$temp],$_SESSION['cpi'][$temp]);
									if($stmnt->fetch())
									{
										$temp++;}
									else
										break;
					}
			}
		
		
		function getGradeCard($roll_number,$year,$sem)
			{		
					$temp=0;
					$conn= $this->Connection();
					$sql =  "call course_grades( ?  , ? , ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('sii',$roll_number,$year,$sem);
					$stmnt->execute();			
					while(1)
					{
						$stmnt->bind_result($_SESSION['course_number'][$temp],$_SESSION['course_name'][$temp],$_SESSION['lecture_credit'][$temp],$_SESSION['tutorial_credit'][$temp],$_SESSION['practical_credit'][$temp],$_SESSION['grade'][$temp]);
									if($stmnt->fetch())
									{
										$temp++;
									}
									else
										break;
					}
				
				
			}

	
   }
?>