<?php
include "/classes/sql.php";
class Login extends Database {

	function Validate($user,$pass)
		{
			$conn=$this->Connection();
			/*$sql = "call login('".$user."',".$pass."')";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) 
				{ 
					while($row = $result->fetch_assoc()) 
					{
					session_start();
					$_SESSION['role_id']=$row["role_id"];         
					$conn->close();
					if[$_SESSION['role_id']==0]  //stu
						{
							$this->giveDetailsStudent($user);
							header("Location: ./start.php");
						}
					else if ($_SESSION['role_id']==1)
						header("Location: ./start.php"); //faculty
					else if ($_SESSION['role_id']==2)
						header("Location: ./start.php"); //admin
					else
						header("Location: ./failure.php"); //login err
					} 		
				}
			else 
				{
					$conn->close();
					header("Location: ./failure.php");
	   
				}*/

				if($user=='rikith'&&$pass=='lol')
				{
						header("Location: ./regis.php");
						//header("Location: ./.php");
					$_SESSION['student_name']='rikith';
					$_SESSION['student_id']='1401013';
					$_SESSION['branch']='ECE';
					$_SESSION['backlog']=1;
					$_SESSION['year']='2011';
						header("Location: ./regis.php");
					
				}
		}

	}

?>    