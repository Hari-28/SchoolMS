<?php

require('fpdf.php');


class grade extends FPDF	
		{

		function header(){                               #............header........
			
			$this->SetMargins(1.29,0.94,1.30);
			$tempy=0.94;
			$tempx=1.29;
			$this->SetFont('Arial','B',12);
			$this->Image('IIITG.jpg',$tempx,$tempy,0.45,0.61,'','http://www.iiitg.ac.in/');
			$temp1x=$tempx + 1.48;
			$this->Image('hindi.jpg',$temp1x,$tempy,3.5,0.30,'','http://www.iiitg.ac.in/');     #......replace 'IIITG.jpg' with the HINDI title image........
			$this->SetXY(1.29+0.5, 0.94+0.3);
			$this->Cell(0,0.31,'INDIAN INSTITUTE OF INFORMATION TECHNOLOGY GUWAHATI',0,0,'C',0);
			$this->SetXY(1.29, 0.94+0.69);
			$this->Cell(0,0,'',1,0,'C',0);

		}






	function particulars($name, $roll, $prog, $branch){                          #........particulars of the student........
		
		$this->Ln(0.2);
		$this->Cell(0,0.28,'GRADE SHEET',0,0,'C',0);
		$this->Ln(0.34);
		$this->SetFont('Arial','',11);
		$this->Cell(1.3,0.30,'Name            : ',0,0,'L',0);
		$this->SetFont('Arial','B',11);
		$this->Cell(1,0.30,$name,0,0,'L',0);                                   #....name....
		$this->Ln(0.45);
		$this->SetFont('Arial','',11);
		$this->Cell(1.3,0.30,'Roll Number  : ',0,0,'L',0);
		$this->SetFont('Arial','B',11);
		$this->Cell(1,0.30,$roll,0,0,'L',0);                                   #....roll number....
		$this->Ln(0.45);
		$this->SetFont('Arial','',11);
		$this->Cell(1.3,0.30,'Programme    : ',0,0,'L',0);
		$this->SetFont('Arial','B',11);
		$this->Cell(0.1,0.30,$prog,0,0,'L',0);                               #....program name....	
		$this->SetX($this->GetX()+1.3);
		$this->SetFont('Arial','',11);
		$this->Cell(1.0,0.30,'Discipline   : ',0,0,'L',0);
		$this->SetFont('Arial','B',11);
		$this->Cell(1.3,0.30,$branch,0,0,'L',0);                                   #....branch name....

		}




	function tablehead ($sem,$acadyear){                                 #....initial part of table(without the actual table values).....
	
		$this->Ln(0.5);	
		$this->SetFont('Arial','B',10);
		$this->Cell(0,0.21,$sem.' Semester of Academic Year '.$acadyear,1,0,'C',0);
		$this->Ln();
		$this->Cell(1,0.19,'Course','LTR',0,'C',0);		
		$this->Cell(2.7,0.19,'Course Title','LTR',0,'L',0);
		$this->Cell(0.9,0.19,'Credit','LTR',0,'L',0);
		$this->Cell(0,0.19,'Grade','LTR',0,'C',0);
		$this->Ln();
		$this->Cell(1,0.19,'Number','LRB',0,'C',0);
		$this->Cell(2.7,0.19,'','LRB',0,'L',0);
		$this->Cell(0.9,0.19,'','LRB',0,'L',0);
		$this->Cell(0,0.19,'Obtained','LRB',0,'C',0);
}






	function maintable(){                          #.....inject data here...........
		$temp=0;
		$totalcredits=0;
		$this->SetFont('Arial','',10);
		while(isset($_SESSION['course_number'][$temp]))
		{
		$this->Ln();                                           #...value1....                      
		$this->Cell(1,0.21,$_SESSION['course_number'][$temp],1,0,'C',0);
		$this->Cell(2.7,0.21,$_SESSION['course_name'][$temp],'1',0,'L',0);
		$this->Cell(0.9,0.21,($_SESSION['lecture_credit'][$temp]+$_SESSION['tutorial_credit'][$temp])*2+$_SESSION['practical_credit'][$temp],'1',0,'C',0);
		$totalcredits+= ($_SESSION['lecture_credit'][$temp]+$_SESSION['tutorial_credit'][$temp])*2+$_SESSION['practical_credit'][$temp];
		$this->Cell(0,0.21,$_SESSION['grade'][$temp],'1',0,'C',0); 
		$temp++;
		}
		$this->tableend($totalcredits,9,9);
}


function tableend($totalcredits,$spi,$cpi){                       #....end of table displaying total credits, spi and cpi.....
$this->Ln();     
$this->Cell(3.7,0.21,'Total Credits =','LTR',0,'R',0);
$this->SetFont('Arial','B',10);
$this->Cell(0.9,0.21,$totalcredits,'LTR',0,'C',0);
$this->SetFont('Arial','',10);
$this->Cell(0,0.21,'','LTR',0,'C',0);
$this->Ln();     
$this->Cell(3.7,0.19,'(for the calculation of SPI and CPI)','LRB',0,'R',0);
$this->Cell(0.9,0.19,'','LRB',0,'C',0);
$this->Cell(0,0.19,'','LRB',0,'C',0);

$this->SetFont('Arial','B',10);
$this->Ln();     
$this->Cell(3.7+0.9,0.21,'Semester Performance Index(SPI) =',1,0,'R',0);
$this->Cell(0,0.21,$spi,1,0,'L',0);

$this->Ln();     
$this->Cell(3.7+0.9,0.21,'Cumulative Performance Index(CPI) =',1,0,'R',0);
$this->Cell(0,0.21,$cpi,1,0,'L',0);
}

	function optionalnote(){                               #....optional note for all except the eighth sem students....
		
		$this->Ln();
		$this->Cell(0.4,0.21,'Note:',0,0,'L',0);
		$this->SetFont('Arial','I',10);
		$this->Cell(0,0.21,'Student has not completed the programme.',0,0,'L',0);
	}

function signoff(){          #....signing off (includes system date, directors sign, and the footer conatining grading system info)....

		$this->Ln();
		$this->SetX(3.7+0.9);
		$this->Image('signature.png',$this->GetX() + 1.29,$this->GetY(),1.47,0.59,'','');    #....change 'IIITG.jpg' with image file of the dir's sign....
		$this->Ln(0.59);
		$this->SetFont('Arial','',10);
		$this->Cell(0.4,0.18,'Date:',0,0,'L',0);
		$this->SetFont('Arial','B',10);
		$this->Cell(1,0.18,date("F j, Y"),0,0,'L',0);
		$this->SetX(3.7+0.9+1.29);
		$this->SetFont('Arial','',10);
		$this->Cell(0,0.18,'(Prof. Gautam Barua)',0,0,'L',0);
		$this->Ln();
		$this->SetX(3.7+0.9+1.29);
		$this->SetFont('Arial','B',10);
		$this->Cell(0,0.16,'Mentor Director',0,0,'C',0);
		$this->Ln();
		$this->SetX(3.7+0.9+1.29);
		$this->Cell(0,0.16,'IIIT Guwahati',0,0,'C',0);


#.....footer(standard grading system).....

		$this->Ln();
		$this->Cell(0,0,'',1,0,'C',0);
		$this->Ln();
		$this->Cell(0,0.17,'Grading System:',0,0,'L',0);
		$this->SetFont('Arial','',10);
		$this->Ln();
		$this->Cell(0,0.17,'Letter Grades & Grade Points',1,0,'C',0);
		$this->Ln();
		$this->Cell(1.35,0.17,'Letter Grades',1,0,'C',0);
		$this->Cell(0.57,0.17,'AA',1,0,'C',0);
		$this->Cell(0.57,0.17,'AB',1,0,'C',0);
		$this->Cell(0.57,0.17,'BB',1,0,'C',0);
		$this->Cell(0.57,0.17,'BC',1,0,'C',0);
		$this->Cell(0.57,0.17,'CC',1,0,'C',0);
		$this->Cell(0.57,0.17,'CD',1,0,'C',0);
		$this->Cell(0.57,0.17,'DD',1,0,'C',0);
		$this->Cell(0.57,0.17,'F(Fail)',1,0,'C',0);
		$this->Ln();
		$this->Cell(1.35,0.17,'Grade Points',1,0,'C',0);
		$this->Cell(0.57,0.17,'10',1,0,'C',0);
		$this->Cell(0.57,0.17,'9',1,0,'C',0);
		$this->Cell(0.57,0.17,'8',1,0,'C',0);
		$this->Cell(0.57,0.17,'7',1,0,'C',0);
		$this->Cell(0.57,0.17,'6',1,0,'C',0);
		$this->Cell(0.57,0.17,'5',1,0,'C',0);
		$this->Cell(0.57,0.17,'4',1,0,'C',0);
		$this->Cell(0.57,0.17,'0',1,0,'C',0);
		$this->Ln();
		$this->Cell(0,0.17,'PP = Passed, NP = Not Passed, AU = Audit Course',0,0,'L',0);
		$this->Ln();
		$this->Cell(0,0.17,'*Courses awarded with PP/NP letter grades are excluded in SPI and CPI calculations',0,0,'L',0);
		$this->Ln();
		$this->Ln();
		$this->Cell(1.9,0.17,'Minimum Graduating CPI :',0,0,'J',0);
		$this->Cell(0,0.17,'04.00 (for Bachelor of Technology degree)',0,0,'L',0); 
		$this->Ln();
		$this->Cell(1.9,0.17,'Maximum CPI                   :',0,0,'J',0);
		$this->Cell(0,0.17,'10.00 (for all degrees)',0,0,'L',0); 
		$this->Ln();
		$this->Cell(0,0,'',1,0,'L',0);
}

}    #....end of class......


		session_start();
		
		$pdf = new grade('P','in','Letter');
		$pdf->SetAuthor('IIITG');
		$pdf->SetTitle('Semester Grade Card');
		$pdf->AddPage();
		$pdf->header();
		$pdf->particulars($_SESSION['student_name'],$_SESSION['roll_number'],$_SESSION['programme_name'],$_SESSION['department_name']);
		$pdf->tablehead('First','2014 - 2015');
		$pdf->maintable();
		$pdf->optionalnote();
		$pdf->signoff();
		$pdf->Output();
?>