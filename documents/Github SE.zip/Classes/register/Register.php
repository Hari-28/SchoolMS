<?php
//include './classes/database/Database.php';
class Register extends Database{
	
		function registerStudent()
			{
				$registeredCourses="start";
					if(count($_GET)>=1)
						{
							foreach ( $_GET as $x => $y)
								{
									if($y!="none")
										{
										if($registeredCourses=="start")
											$registeredCourses=$y;
										else
											$registeredCourses=$registeredCourses.",".$y;
										}
								}
							//echo $registeredCourses;
							$this->insertRegister($registeredCourses);
						}
			}
		
		function insertRegister($string)
				{
					$conn= $this->Connection();
				/*	$sql =  "call add_registration_courses(?,?)";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('ss',$_SESSION['roll_number'],$string);
					$stmnt->execute();
				//$conn->close();
					*/
					
			$conn = $this->Connection();
			$sql =  "call add_registration_courses('".$_SESSION['roll_number']."','".$string."')";
			 $conn->query($sql);
			$conn->close();
			header("Location: ./studenthomepage.php");
				}   
					
				
				
		
  }
?>