<?php
include "/classes/sql.php";

class Info extends Database {

	function giveSem($id)
		{
			session_start();
			$conn=$this->Connection();
			$sql = "select give_sem('".$id."')";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) 
				{
					while($row = $result->fetch_assoc()) 
						{
							$_SESSION['sem']=$row["sem"];
						}
					$conn->close();
				}
			else 
				{
					$conn->close();
					return false;
				}		
		}

	function studentBacklogCourses($id)
		{
			session_start();
			$_SESSION['number_backlogs']=0;
			$conn=$this->Connection();
			$sql = "call student_backlog_courses('".$id."')";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) 
				{
					while($row = $result->fetch_assoc()) 
						{
							$_SESSION['backlog_course_name'][$_SESSION['number_backlogs']]=$row["Backlog_course_name"];
							$_SESSION['backlog_course_number'][$_SESSION['number_backlogs']]=$row["course_number"];
							$_SESSION['backlog_credit'][$_SESSION['number_backlogs']]=$row["credits"];
							$_SESSION['number_backlogs']++;
						}
					$conn->close();
				}
			else 
				{
					$conn->close();
				}		
		
		}

	function giveStudentCourses($id)
		{
			session_start();
			$_SESSION['number_courses']=0;
			$conn=$this->Connection();
			$sql = "call give_student_courses('".$id."')";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) 
				{
					while($row = $result->fetch_assoc()) 
						{
							$_SESSION['course_name'][$_SESSION['number_courses']]=$row["course_name"];
							$_SESSION['course_number'][$_SESSION['number_courses']]=$row["course_number"];
							$_SESSION['lecture_credits'][$_SESSION['number_courses']]=$row["lecture_credits"];
							$_SESSION['tutorial_credits'][$_SESSION['number_courses']]=$row["tutorial_credits"];
							$_SESSION['practical_credits'][$_SESSION['number_courses']]=$row["practical_credits"];
							//$_SESSION['course_type'][$_SESSION['number_courses']]=Converter($row["course_type"]);
							$_SESSION['number_courses']++;
						}
					$conn->close();
				}
			else 
				{
					$conn->close();
				}		
		
		}

		
		
		
?>