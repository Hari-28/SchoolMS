<?php
include './classes/database/Database.php';
class Register extends Database{
	
		function registerStudent()
			{
				$registeredCourses="";
					if(count($_POST)>1)
						{
							for each ($_POST as $x => $y)
								{
								   if($y==1)
									   $registeredCourses=$registeredCourses.",".$x
								}
							echo $registeredCourses;
						}
			}
		
		
  }
?>