<?php
include './classes/database/Database.php';
class Login extends Database
	{
	
	 function validation()
		{
			if(isset($_POST['username']))
			{
				$conn= $this->Connection();
				$sql =  "call login ( ? , ? )";
				$stmnt = $conn->prepare($sql);
				$stmnt->bind_param('ss',$_POST['username'],$_POST['password']);
				//
				$stmnt->execute();
				$stmnt->bind_result($_SESSION['role_id']);
				$row = $stmnt->fetch();
				
				

				}
		}
		
	 function loginHandler()
		{
			if(isset($_SESSION['role_id']))
			 {
				if($_SESSION['role_id']==0)
					header("Location: ./studenthomepage.php");
				if($_SESSION['role_id']==1)
					header("Location: ./facultyhomepage.php");
				if($_SESSION['role_id']==2)
					header("Location: ./adminhomepage.php");
			 }
		}
	
	function errorHandler()
		{
			if(isset($_SESSION['role_id']))
				{
					if($_SESSION['role_id']==-1)
						{
							unset($_SESSION['role_id']);
							echo "** LOGIN ERROR";	
						}
				}
		}
	
	}


?>