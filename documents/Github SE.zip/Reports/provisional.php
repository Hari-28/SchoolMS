<?php

require('provisionalgcclass.php');

$pdf = new provgrade('P','in','A4');
$pdf->SetAuthor('IIITG');
$pdf->SetTitle('Grade Card (Provisional)');
$pdf->AddPage();
$pdf->SetAutoPageBreak(0,0);
$pdf->headof();
$pdf->particulars('Shoaib','1501049','Bachelor of Technology','Computer Science and Engineering');
$pdf->table(7);              #.....input the current sem no. here.....
$pdf->SetAutoPageBreak(1,0);
$pdf->tailof();
$pdf->Output();




?>