<?php
include "/classes/sql.php";

class Registration extends Database {


	function genrateCourseList()
		{
			$courses="";
			foreach($_POST as $key => $value)
				{
					if($value=='ok')
					$courses=$courses.",".$key;
				}
			return $courses;
		}
	
	function insertIntoDatabase()
		{
			session_start();
			$conn=$this->Connection();
			sql= "call register_for_course('".$this->genrateCourseList().",".$_SESSION['roll'].")";
			$result = $conn->query($sql);
			if($result==TRUE)
				return 1;
			else
				return 0;
		}
?>