<?php

class RegStart extends Database{
	
		function RegStart()
			{
					if(isset($_POST['start']))
					{
					$conn= $this->Connection();
					$sql =  "call start_reg_session()";
					$stmnt = $conn->prepare($sql);
					$stmnt->execute();
				//	$stmnt->bind_result($boolean);
			//		$row = $stmnt->fetch();
			       /* if($boolean==1)
						echo "Succesfully Reset password";
					else
						echo "No such roll number exists";
			*/
					}
			}
		
		
		
   }
?>