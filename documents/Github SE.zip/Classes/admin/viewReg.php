<?php

class View extends Database{
	
		function csvUploader()
			{
				$this->fileUp();
					if(isset($_POST['add_user']))
					{
							$file = fopen("temp","r");
							print_r(fgetcsv($file));
							fclose($file);
					}
					if(isset($_POST['add_student']))
					{
					
					}
					if(isset($_POST['add_courses']))
					{
					
					}
					if(isset($_POST['add_faculty']))
					{
					
					}
					if(isset($_POST['add_departments']))
					{
					
					}
					if(isset($_POST['add_programme']))
					{
					
					}
					if(isset($_POST['add_project']))
					{
					
					}
					if(isset($_POST['set_reg']))
					{
							$file = fopen("temp","r");
							while(! feof($file))
							{
								$values=fgetcsv($file);
								$this->acad_aprove($values);
							}
							fclose($file);
							
						
					}
					if(isset($_POST['set_reg']))
					{
						
					}
			}
		
		function StuRegDetails()
			{
					
			}
		
		function acad_aprove($sem,$year)
			{
					
				$conn= $this->Connection();
					$sql =  "call view_registered_students( ? , ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('ii',$sem,$year);
					$stmnt->execute();
					$stmnt->bind_result($_SESSION['name'][$temp],$_SESSION['roll_number'][$temp],$_SESSION['dept_name'][$temp]);
					$conn->close();
			
			
			}
		
		function fileUp()
			{
			if(isset($_FILES['datafile']))
				{
				move_uploaded_file($_FILES["datafile"]["tmp_name"], "temp");
			//	header("Location: ./l.php");				

				}
   
			}
}
?>