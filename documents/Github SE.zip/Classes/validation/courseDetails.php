<?php
	
		function GetDetails()
			{
					$temp=0;
					$conn= $this->Connection();
					$sql =  "call names_of_courses( ? ,? , ? )";
					$stmnt = $conn->prepare($sql);
					$stmnt->bind_param('sss',$_SESSION['roll_number'],$_SESSION['programme_name'],$_SESSION['department_name']);
					$stmnt->execute();
					while(1)
						{
							$stmnt->bind_result($_SESSION['course_type'][$temp],$_SESSION['course_number'][$temp],$_SESSION['course_name'][$temp],$_SESSION['lecture'][$temp],$_SESSION['tutorial'][$temp],$_SESSION['practical'][$temp]);
						if($stmnt->fetch())
								{
									$_SESSION['total_credits'][$temp]=$_SESSION['lecture'][$temp]*2+$_SESSION['tutorial'][$temp]*2+$_SESSION['practical'][$temp];
									$_SESSION['course_type_name'][$temp]=$this->convertCourseTypeId($_SESSION['course_type'][$temp]);
									$temp++;
									continue;
								}
							else
									break;
						}
				
			}
		
		function emailValidator($email)
			{
				if(filter_var($email, FILTER_VALIDATE_EMAIL))
					return "true";
				else
					return "false";
				
			}
		
  
?>