
<?php
require('fpdf.php');
class provgrade extends FPDF{

function headof(){                               #............header........
	$this->SetMargins(0.7,0.7,0.7);
	$tempy=0.76;
	$tempx=1.1;
	$this->SetFont('Arial','B',12);
	$this->Image('IIITG.jpg',$tempx,$tempy,0.61,0.61,'','http://www.iiitg.ac.in/');
	$temp1x=$tempx + 1.48;
	$this->Image('IIITG.jpg',$temp1x,$tempy,4,0.30,'','http://www.iiitg.ac.in/');     #......replace 'IIITG.jpg' with the HINDI title image........
	$this->SetXY(1.29+0.5, 0.94+0.3);
	$this->Cell(0,0.31,'INDIAN INSTITUTE OF INFORMATION TECHNOLOGY GUWAHATI',0,0,'C',0);
	$this->SetXY(1.29, 0.94+0.69);
}

function particulars($name,$roll, $prog, $branch){                                        #........print the partiulars of the student.....
	$this->Ln(0.2);                                                                        #....input parameteres...name, rollno., programme, and branch....
	$this->Cell(0,0.28,'Bachelor of Technology Grade Card (Provisional)',0,0,'C',0);
	$this->Ln(0.5);
	$this->SetFont('Arial','B',11);
	$this->Cell(1.3,0.30,'Program Duration: 4 Years',0,0,'L',0);
	$this->SetX($this->GetX()+3.5);
	$this->Cell(1.3,0.30,'Semesters: Eight(8)',0,0,'L',0);
	$this->Ln(0.3);
	$this->Cell(1.3,0.30,'Name: '.$name,0,0,'L',0);
	$this->SetX($this->GetX()+3.5);
	$this->Cell(1.3,0.30,'Roll No.: '.$roll,0,0,'L',0);
	$this->Ln(0.3);
	$this->Cell(1.3,0.30,'Discipline: '.$branch,0,0,'L',0);
	$this->Ln(0.5);
}

function table($semno){                     #......function for creatig tables.....input param. = currrent sem no(or last sem no.)...........
	$this->SetFont('Arial','B',9);
	
		if($semno==1)                       #.... if just one sem--no need of two columns..............
		{
			$this->Ln();                    #.......heading(title)..............
			$this->Cell(0.6,0.19,'Course','TB',0,'C',0);
			$this->Cell(1.1,0.19,'Course Title','TB',0,'L',0);
			$this->Cell(0.2,0.19,'L','TB',0,'C',0);
			$this->Cell(0.2,0.19,'T','TB',0,'C',0);
			$this->Cell(0.2,0.19,'P','TB',0,'C',0);
			$this->Cell(0.2,0.19,'C','TB',0,'C',0);
			$this->Cell(0.4,0.19,'Cr.','TB',0,'C',0);
			$this->Cell(0.4,0.19,'Gr.','TB',0,'C',0);
			$this->Ln();
			$this->Ln();
			
			
			#...........main table..............
			
			#....printing the main table(subjects).....
			$this->Cell(3.3,0.19,'Semester '.$semno.' (July - Nov)'.date("Y"),0,0,'C',0);
			$this->SetFont('Arial','',9);
			for ($x = 0; $x < 8 ; $x++) {                #.....iteration always to be run 8 times....
				$this->Ln();                              #......if there are less no. of subjects, print same no. of cells but with empty text/ string.....
				$this->Cell(0.6,0.18,'CS101',0,0,'C',0);   #...... i.e. like :- $this->Cell(0.6,0.18,'',0,0,'C',0)........... 
				$this->Cell(1.1,0.18,'Subject 1',0,0,'L',0);
				$this->Cell(0.2,0.18,'5',0,0,'C',0);
				$this->Cell(0.2,0.18,'3',0,0,'C',0);
				$this->Cell(0.2,0.18,'2',0,0,'C',0);
				$this->Cell(0.2,0.18,'4',0,0,'C',0);
				$this->Cell(0.4,0.18,'9.80',0,0,'C',0);
				$this->Cell(0.4,0.18,'AA',0,0,'C',0);  
			}
			
			
			
			$this->Ln();           #.......line breaks before the signing off part....
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
			$this->Ln();
		}
		
		
		
		elseif($semno>1)     #.... if more than 1 sems....
		{
			$currsem=1;
			$this->Ln();
			
			
			for ($x = 0; $x < 2 ; $x++){                             #.......print two titles(for two columns)...... 
				$this->Cell(0.6,0.19,'Course','TB',0,'C',0);
				$this->Cell(1.1,0.19,'Course Title','TB',0,'L',0);
				$this->Cell(0.2,0.19,'L','TB',0,'C',0);
				$this->Cell(0.2,0.19,'T','TB',0,'C',0);
				$this->Cell(0.2,0.19,'P','TB',0,'C',0);
				$this->Cell(0.2,0.19,'C','TB',0,'C',0);
				$this->Cell(0.4,0.19,'Cr.','TB',0,'C',0);
				$this->Cell(0.4,0.19,'Gr.','TB',0,'L',0);
				$this->Cell(0.05,0.19,'','TB',0,'C',0);
			}
			
			$this->Ln();
			$topoc2x = $this->GetX() + 3.3;              #......store the coordinates of column 2.....
			$topoc2y = $this->GetY() - 0.19;
			
			
			
			while($currsem <= $semno){               #... for printing odd sem tables(i.e tables in the first column).......
				if($currsem!=1){
					$this->Ln();
				}
				$this->Ln();
				$this->SetFont('Arial','B',9);
				$this->Cell(3.3,0.19,'Semester '.$currsem.' (July - Nov) 2014',0,0,'C',0);
			
				$this->SetFont('Arial','',9);
				for ($x = 0; $x < 7 ; $x++) {          #......printing main table...iteration always run 8 times....
					$this->Ln();                         #....if subjects less than 8, print all the given cells but print remaining cells empty...
					$this->Cell(0.6,0.18,'CS101',0,0,'C',0);   #.......^^inorder  to keep alignment between two adj tables right...
					$this->Cell(1.1,0.18,'Subject 1',0,0,'L',0);
					$this->Cell(0.2,0.18,'5',0,0,'C',0);
					$this->Cell(0.2,0.18,'3',0,0,'C',0);
					$this->Cell(0.2,0.18,'2',0,0,'C',0);
					$this->Cell(0.2,0.18,'4',0,0,'C',0);
					$this->Cell(0.4,0.18,'9.80',0,0,'C',0);
					$this->Cell(0.4,0.18,'AA',0,0,'L',0);
					$this->Cell(0.05,0.18,'',0,0,'C',0);					
				}
			$currsem = $currsem + 2;
			}
			$endofc1x = $this->GetX();            #...storing the coordinates of end of column 1 (in order to return here after printing the 2nd column).....
			$endofc1y = $this->GetY() + 0.18;
			if($currsem==9){                       #.....if the sems are >=7, giving some extra line break in order to take the terminal part to the next page.....
				$endofc1y=$endofc1y+0.2;
			}
			
			$currsem = 2;                        #....start printing column 2...
			$this->SetXY($topoc2x, $topoc2y);      #...go to the saved column 2 coordinates.....
			
			while($currsem <= $semno){             #.........printing column 2....
				$this->Ln();
				$this->Ln();
				$this->SetX($this->GetX() + 3.3);
				$this->SetFont('Arial','B',9);
				$this->Cell(3.3,0.19,'Semester '.$currsem.' (Jan - May) 2014',0,0,'C',0);
			
				$this->SetFont('Arial','',9);
				for ($x = 0; $x < 8 ; $x++) {       #.......always have 8 iterations....if subjects < 8 print same no. of cells but all empty....
					$this->Ln();                     # ........^^inorder to keep the alignment right.....
					$this->SetX($this->GetX() + 3.3);
					$this->Cell(0.6,0.18,'CS101',0,0,'C',0);
					$this->Cell(1.1,0.18,'Subject 1',0,0,'L',0);
					$this->Cell(0.2,0.18,'5',0,0,'C',0);
					$this->Cell(0.2,0.18,'3',0,0,'C',0);
					$this->Cell(0.2,0.18,'2',0,0,'C',0);
					$this->Cell(0.2,0.18,'4',0,0,'C',0);
					$this->Cell(0.4,0.18,'9.80',0,0,'C',0);
					$this->Cell(0.4,0.18,'AA',0,0,'L',0);  
				}
			$currsem = $currsem + 2;
			}
			
			#.......some changes in coordinates of end of column 1(in order to give proper spacing between tbles and signing off part)....
			if($semno > 4){
				$this->SetXY($endofc1x, $endofc1y + 0.35);
			}
			elseif($semno <= 4){
				$this->SetXY($endofc1x, $endofc1y + 1.1);
			}
			
			
			
		}
		
}

function tailof(){                    #......ending part.......
	$this->Ln();
	$this->SetFont('Arial','BU',10);
	$this->Cell(0,0.19,'Semester and Cumulative Performance Index (S.P.I and C.P.I)',0,0,'C',0);
	$this->Ln();
	$this->SetFont('Arial','',9);                   #.........making table of spi and cpi...
	$this->Cell(0.9,0.19,'','LTB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem I','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem II','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem III','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem IV','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem V','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem VI','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem VII','TB',0,'C',0);
	$this->Cell(0.6,0.19,'Sem VIII','TB',0,'C',0);
	$this->SetFont('Arial','B',9);
	$this->Cell(0.9,0.19,'Status',1,0,'C',0);
	for ($x = 1; $x <= 2 ; $x++){
		$this->Ln();
		if($x==1){
			$this->Cell(0.9,0.19,'S.P.I','LTB',0,'C',0);
		}
		else{
			$this->Cell(0.9,0.19,'C.P.I','LTB',0,'C',0);
		}
		$this->SetFont('Arial','',9);
		for ($y = 1; $y <= 8 ; $y++){
			$this->Cell(0.6,0.19,'9.8','TB',0,'C',0);
		}
		if($x==1){
			$xc=$this->GetX();
			$yc=$this->GetY();
		}
	}
	$this->SetFont('Arial','B',9);
	$this->SetXY($xc, $yc);
	$this->Cell(0.9,0.38,'Complete',1,0,'C',0);
	
	
	$this->Ln();                      #.......date and sign................
	$this->Ln();
	$this->Cell(3.3,0.2,date("F j, Y"),0,0,'L',0);
	$this->Cell(0.4,0.2,'',0,0,'L',0);
	$temx=$this->GetX();
	$this->Cell(3.3,0.2,'Souvik Chowdhury',0,0,'C',0);
	$this->Ln();
	$this->SetX($temx);
	$this->Cell(3.3,0.2,'Assistant Registrar (Admin)',0,0,'C',0);
	$this->Ln();
	$this->Cell(0,0,'',1,0,'C',0);
}

}    #....end of class......





?>